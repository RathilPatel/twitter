var mysql = require('mysql');



// con.connect(function(err) {
//   if (err) throw err;
//   console.log("Connected!");
//   //Insert a record in the "customers" table:
//   var sql = "INSERT INTO customers (name, address) VALUES ('Company Inc', 'Highway 37')";
//   con.query(sql, function (err, result) {
//     if (err) throw err;
//     console.log("1 record inserted");
//   });
// });


exports.getdata= function(offset,res){

	var con = mysql.createConnection({
	  host: "35.200.185.117",
	  user: "root",
	  password: "root",
	  database: "twitterdata",charset:"utf8mb4"
	});
	con.connect(function(error){

	  if(error){
	  	console.log(error);
	    return res.json(error);
	  }else{
	    console.log("connected");
	    var sql="select * from tweets limit 10 offset "+offset;
	    con.query(sql,function(error,result){
	    	if(error){
	    		con.end();
	    		return res.send(error);
	    	}else{
	    		con.end();
	    		return res.json(result);
	    	}
	    });
	  }

	});
}

